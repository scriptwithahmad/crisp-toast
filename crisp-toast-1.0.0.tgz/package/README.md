# Crisp Toast 🍞

A lightweight, beautiful, and highly customizable vanilla JavaScript toast notification library. Designed for modern web applications with premium aesthetics.

![NPM Version](https://img.shields.io/npm/v/crisp-toast)
![License](https://img.shields.io/npm/l/crisp-toast)

## Table of Contents
- [Features](#features)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Usage](#usage)
  - [Toast Types](#toast-types)
  - [Variants](#variants)
  - [Colors](#colors)
  - [Placements](#placements)
  - [Promises](#promises)
- [API Reference](#api-reference)
- [License](#license)

## Features

- 🚀 **Vanilla JS**: No dependencies, works anywhere.
- 🎨 **Beautiful Designs**: Support for Solid, Bordered, and Flat variants.
- 🌈 **Modern Colors**: Built-in palettes (Primary, Success, Danger, etc.) with dark mode support.
- 🧭 **Precise Placement**: 6 different anchor positions.
- ⏳ **Progress Bar**: Visual countdown for auto-dismissal.
- 📦 **Promise Support**: Easy handling of loading states.
- 🛠️ **Fully Customizable**: Override styles, icons, and behavior.

## Installation

```bash
npm install crisp-toast
```

Or via yarn:

```bash
yarn add crisp-toast
```

## Quick Start

Import the library and its styles:

```javascript
import { toast } from 'crisp-toast';
import 'crisp-toast/style.css';

// Simple toast
toast('Hello World!');

// Success toast
toast.success('Settings saved!');
```

## Usage

### Toast Types

Crisp Toast provides specialized methods for common states:

```javascript
toast('Normal toast');
toast.success('Task completed!');
toast.error('Something went wrong.');
toast.warning('Check your input.');
toast.info('New update available.');
toast.loading('Processing...');
```

### Variants

Choose between three premium variants:

```javascript
toast.success({
  title: 'Success!',
  variant: 'bordered' // 'solid' | 'bordered' | 'flat' (default: 'bordered')
});
```

### Colors

Map toasts to your brand or state:

```javascript
toast({
  title: 'Custom Color',
  color: 'secondary' // 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger'
});
```

### Placements

Control exactly where the toast appears:

```javascript
toast({
  title: 'Top Center Toast',
  placement: 'top-center'
  // Options: 'top-left', 'top-center', 'top-right', 'bottom-left', 'bottom-center', 'bottom-right'
});
```

### Promises

Handle asynchronous operations with ease:

```javascript
const savePromise = saveData();

toast.promise(savePromise, {
  loading: 'Saving your changes...',
  success: (data) => `Saved successfully: ${data.name}`,
  error: (err) => `Failed to save: ${err.message}`
});
```

## API Reference

### `toast(options | string)`

The main function. You can pass a string for a simple message or an options object.

#### Options Object

| Property | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `title` | `string` | `undefined` | The main message of the toast. |
| `description`| `string` | `undefined` | Secondary text below the title. |
| `variant` | `'solid' \| 'bordered' \| 'flat'` | `'bordered'` | The visual style of the toast. |
| `color` | `ToastColor` | `'default'` | The color theme. |
| `placement` | `ToastPlacement` | `'bottom-right'` | Position on the screen. |
| `duration` | `number` | `3000` | Auto-dismissal time in ms. `0` or `Infinity` to keep forever. |
| `progressBar`| `boolean` | `true` | Whether to show the progress bar. |
| `radius` | `'none' \| 'sm' \| 'md' \| 'lg' \| 'full'` | `'md'` | Corner rounding. |
| `icon` | `string \| HTMLElement \| boolean` | `true` | Pass HTML string, element, or `false` to hide. |
| `endContent` | `HTMLElement \| function` | `undefined` | Custom content at the end of the toast. |
| `action` | `{ label: string, onClick: function }`| `undefined` | Add a call-to-action button. |
| `onClose` | `function` | `undefined` | Callback when toast is dismissed. |
| `customStyle`| `CSSStyleDeclaration` | `{}` | Custom CSS overrides. |

## License

MIT © [Ahmad](https://github.com/scriptwithahmad)
